const form = document.getElementById('emailForm');
const message = document.getElementById('status');

//event listener for form when submitted
form.addEventListener('submit', (event) => {
    event.preventDefault();

    message.textContent = "Submitted!";
    message.style.color = "white";
});