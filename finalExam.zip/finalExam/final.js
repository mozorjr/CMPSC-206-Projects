const form2 = document.getElementById('merchForm');
const modal = document.getElementById('popupModal');
const modalMessage = document.getElementById('modalMessage');
const modalCost = document.getElementById('modalCost');
const closeModal = document.getElementById('closeModal');

//event listener for form 
form2.addEventListener('submit', (event) => {
    event.preventDefault(); 

    const total = calculateTotal();

    modalMessage.textContent = "Thank you for your order!";
    modalCost.textContent = `Total Spent: $${total}`;

    modal.style.display = "block";
});

// event listener to close pop up box
closeModal.addEventListener('click', () => {
    modal.style.display = "none";
});

//function to calculate how much user spent
function calculateTotal() {
    
    const prices = {
        keyboard: 90,
        mouse: 120,
        mousepad: 80,
    };

    const keyboard = document.querySelector('input[name="keyboard"]');
    const mouse = document.querySelector('input[name="mouse"]');
    const mousepad = document.querySelector('input[name="mousepad"]');

    let total = 0;
    if (keyboard && keyboard.checked) total += prices.keyboard;
    if (mouse && mouse.checked) total += prices.mouse;
    if (mousepad && mousepad.checked) total += prices.mousepad;

    return total; 
}
