//this declares a, b, and c and gives some of these values   
let a = 9;          
let c = 1;          
let b = (a + c) * 2; 
let d = first(a, b);

function first (x, y){
    return x * y;
    
}

//this gets the element demo and sets it to a different value
document.getElementById("demo").innerHTML = "There are currently " + d + " new games coming out!";

//this gets the type of "firstButton" and then changes its content
document.getElementById('firstButton').innerHTML = "Click Me For A Surprise";

//this does the same thing but makes it into its own variable
const element = document.getElementById("firstButton");
 element.style.fontSize = "24px";

//this changes the content of element "2demo"
document.getElementById("2demo").innerHTML = "Join The Fun Now!";

//this is a function that handles the coding for my form
function validateForm() {
  let x = document.forms["myForm"]["email"].value;
  if (x == "") {
    alert("Email must be filled out");
    return false;
  }
}

//this is an event listener that waits for a button to be clicked
element.addEventListener("click", function(){ alert("YOU CLICKED SOMETHING!"); });

//these are all comments 